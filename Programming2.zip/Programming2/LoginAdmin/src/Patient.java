
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.table.TableRowSorter;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author gemin
 */
public class Patient extends javax.swing.JFrame {

    /**
     * Creates new form Patient
     */
    public Patient() {
        initComponents();
        show_user();
        clear();
        setExtendedState(Patient.NORMAL);
    }

 
   private void displayTable() {
    DefaultTableModel model = (DefaultTableModel)table1.getModel();
    int i = table1.getSelectedRow();
    
    // Retrieve the date from the table
    String dateStr = model.getValueAt(i, 4).toString();
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    Date date;
    
    try {
        date = dateFormat.parse(dateStr);
    } catch (Exception e) {
        // Handle the parsing exception if needed
        return;
    }
    // Set the retrieved date to the JCalendar
    tdate.setDate(date);
    
    // Rest of your code...
}
 
    private void clear()
    {
    Gender.setSelectedIndex(-1);
    tdate.setCalendar(null);
    }
    public void show_user(){
          
        try{
           String url = "jdbc:MySQL://localhost:3306/patient";
           String user = "root";
           String pass = "";
        DefaultTableModel model = (DefaultTableModel)table1.getModel();
        model.setRowCount(0);
        Connection con=DriverManager.getConnection(url,user,pass);
        Statement st = con.createStatement();
      
        ResultSet rs = st.executeQuery("SELECT * FROM `user1`");
       
        while (rs.next()){
        
            Vector v = new Vector();
            
            v.add(rs.getString(1));
            v.add(rs.getString(2));
            v.add(rs.getString(3));
            v.add(rs.getString(4));
            v.add(rs.getString(5));
            v.add(rs.getString(6));
            v.add(rs.getString(7));
            model.addRow(v);
        }
        }catch(Exception e){
        
        }
      
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        label4 = new javax.swing.JLabel();
        label1 = new java.awt.Label();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        label5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tphone = new javax.swing.JTextField();
        tname = new javax.swing.JTextField();
        tdate = new com.toedter.calendar.JDateChooser();
        jScrollPane4 = new javax.swing.JScrollPane();
        tallergies = new javax.swing.JTextPane();
        jScrollPane5 = new javax.swing.JScrollPane();
        taddress = new javax.swing.JTextPane();
        save = new javax.swing.JButton();
        updatebutton = new javax.swing.JButton();
        Clear = new javax.swing.JButton();
        Delete = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        Gender = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        btnsearch = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Patient");

        jPanel1.setBackground(new java.awt.Color(0, 153, 204));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 204, 204));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 5, true));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(51, 51, 51));
        jButton1.setText("Dashboard");
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, 100, 30));

        jButton6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton6.setText("Appointments");
        jButton6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, 100, 30));

        jButton7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton7.setText("Patients");
        jButton7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 310, 100, 30));

        label4.setFont(new java.awt.Font("Comic Sans MS", 1, 20)); // NOI18N
        label4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label4.setText("DENTAL ");
        jPanel2.add(label4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, -1, 40));

        label1.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        label1.setText(" APPOINTMENT");
        jPanel2.add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 150, 40));

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-user-24.png"))); // NOI18N
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 90, 40, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-bullet-list-26.png"))); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 30, 30));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-appointment-24.png"))); // NOI18N
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 30, 30));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-tooth-26.png"))); // NOI18N
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 30, 30));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-dental-100.png"))); // NOI18N
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 130, -1));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel12.setText("__________");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 180, 500));

        label5.setFont(new java.awt.Font("Comic Sans MS", 1, 36)); // NOI18N
        label5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label5.setText("Patient");
        jPanel1.add(label5, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 30, 140, 40));

        table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No:", "Name", "Phone", "Address", "Date", "Gender", "Allergies"
            }
        ));
        table1.setToolTipText("");
        table1.setGridColor(new java.awt.Color(255, 255, 255));
        table1.setSelectionBackground(new java.awt.Color(255, 0, 0));
        table1.setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        table1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 310, 850, 190));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Allergies");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 170, 70, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Name");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 100, 40, 20));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Date of Birth");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 100, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Gender");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 100, 50, 20));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Address");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 170, -1, 20));

        tphone.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(tphone, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 180, 150, 30));

        tname.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tname.setMinimumSize(new java.awt.Dimension(84, 24));
        jPanel1.add(tname, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 120, 150, 30));

        tdate.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tdate.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(tdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 120, 150, -1));

        tallergies.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jScrollPane4.setViewportView(tallergies);

        jPanel1.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 190, 150, 40));

        taddress.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jScrollPane5.setViewportView(taddress);

        jPanel1.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 190, 150, 40));

        save.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        save.setText("Save");
        save.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        save.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        jPanel1.add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 250, 80, -1));

        updatebutton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        updatebutton.setText("Update");
        updatebutton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        updatebutton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        updatebutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebuttonActionPerformed(evt);
            }
        });
        jPanel1.add(updatebutton, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 250, 80, -1));

        Clear.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Clear.setText("Clear");
        Clear.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Clear.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearActionPerformed(evt);
            }
        });
        jPanel1.add(Clear, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 250, 80, -1));

        Delete.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Delete.setText("Delete");
        Delete.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Delete.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });
        jPanel1.add(Delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 250, 80, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Phone");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 160, -1, -1));

        Gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        Gender.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Gender.setMinimumSize(new java.awt.Dimension(84, 24));
        Gender.setPreferredSize(new java.awt.Dimension(84, 24));
        jPanel1.add(Gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 120, 150, 30));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-dental-decay-100.png"))); // NOI18N
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 110, 100));
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 110, -1, -1));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-name-24.png"))); // NOI18N
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 110, 40, 50));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-phone-24.png"))); // NOI18N
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 170, 30, 50));

        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-allergies-32.png"))); // NOI18N
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 190, 40, 40));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-birthday-date-24.png"))); // NOI18N
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 110, 40, 50));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-gender-26.png"))); // NOI18N
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 110, 40, 50));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-address-32.png"))); // NOI18N
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 190, 40, 40));

        txtSearch.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        txtSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchActionPerformed(evt);
            }
        });
        txtSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearchKeyReleased(evt);
            }
        });
        jPanel1.add(txtSearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 20, 200, 30));

        btnsearch.setText("Search");
        btnsearch.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });
        jPanel1.add(btnsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 20, 90, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1033, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearActionPerformed
 if(key==0){
        
            JOptionPane.showMessageDialog(this, "Missing Information!");
        }else{
         tname.setText("");
         tphone.setText("");
         taddress.setText("");
         tallergies.setText(""); 
         clear();
 }
    }//GEN-LAST:event_ClearActionPerformed

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed

        if(key==0){
        
            JOptionPane.showMessageDialog(this, "Please Select");
        }else{
          try{
         
           Class.forName("com.mysql.cj.jdbc.Driver");
           String url = "jdbc:MySQL://localhost:3306/patient";
           String user = "root";
           String pass = "";
      
         Connection con=DriverManager.getConnection(url,user,pass);
         Statement st = con.createStatement();
         
         String query = "DELETE FROM user1 where id="+key;
         st.executeUpdate(query);
         show_user();
         clear();
         tname.setText("");
         tphone.setText("");
         taddress.setText("");
         tallergies.setText("");
         JOptionPane.showMessageDialog(this,"Delete Successfully!");
         con.close();
     
         
       }catch(Exception ex){
       }
       }
    }//GEN-LAST:event_DeleteActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
        Dashboard dashboard = new Dashboard();
        dashboard.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        dispose();
        Appointment appointment = new Appointment();
        appointment.setVisible(true);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
       
        String name, phone, address, date ,gender, allergies, query;
       
        if(tname.getText().isEmpty() && tphone.getText().isEmpty() && taddress.getText().isEmpty()&& tallergies.getText().isEmpty()){
       JOptionPane.showMessageDialog(this, "Missing Information");
       }else{
         try {
           Class.forName("com.mysql.cj.jdbc.Driver");
           String url = "jdbc:MySQL://localhost:3306/patient";
           String user = "root";
           String pass = "";
           
         Connection con=DriverManager.getConnection(url,user,pass);
         Statement st = con.createStatement();
         
           name = tname.getText();
           phone = tphone.getText();
           address = taddress.getText();
           date = ((JTextField)tdate.getDateEditor().getUiComponent()).getText();
           gender = Gender.getSelectedItem().toString();
           allergies = tallergies.getText();
          query = "INSERT INTO user1 (Name, Phone, Address, Date, Gender, Allergies)"+"VALUES('"+name+"','"+phone+"','"+address+"','"+date+"','"+gender+"','"+allergies+"')";
          st.executeUpdate(query);
          JOptionPane.showMessageDialog(this,"Save Successfully!");
          show_user();
          clear();
         tname.setText("");
         tphone.setText("");
         taddress.setText("");
         tallergies.setText("");
       
         con.close();  
        } catch(Exception e){
        
        }
      }
    }//GEN-LAST:event_saveActionPerformed

    int key = 0;
    private void table1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table1MouseClicked

        boolean n = table1.isEditing();
        
        if(n==false){
        
        DefaultTableModel model = (DefaultTableModel)table1.getModel();
        int i = table1.getSelectedRow();
        key = Integer.valueOf(model.getValueAt(i, 0).toString());
        tname.setText(model.getValueAt(i, 1).toString());
        tphone.setText(model.getValueAt(i, 2).toString());
        taddress.setText(model.getValueAt(i, 3).toString());
        Gender.setSelectedItem(model.getValueAt(i, 5).toString());
        tallergies.setText(model.getValueAt(i, 6).toString());
        displayTable();
        JOptionPane.showMessageDialog(this, "You can't edit this table");
       
        }
    }//GEN-LAST:event_table1MouseClicked

    private void updatebuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebuttonActionPerformed

        String name, phone, address, date , gender, allergies, query;
        
        if(key==0){
        
            JOptionPane.showMessageDialog(this, "Please Select");
        }else{
        
        try{
        
           Class.forName("com.mysql.cj.jdbc.Driver");
           String url = "jdbc:MySQL://localhost:3306/patient";
           String user = "root";
           String pass = "";
          
           name = tname.getText();
           phone = tphone.getText();
           address = taddress.getText();
           date = ((JTextField)tdate.getDateEditor().getUiComponent()).getText();
           gender = Gender.getSelectedItem().toString();
           allergies = tallergies.getText();
         Connection con=DriverManager.getConnection(url,user,pass);
         Statement st = con.createStatement();
         
         query = "update user1 set Name='"+name+"'"+",Phone='"+phone+"'"+",Address='"+address+"'"+",Date='"+date+"'"+",Gender='"+gender+"'"+",Allergies='"+allergies+"'"+"where id="+key;                           
         st.executeUpdate(query);
         show_user();
         JOptionPane.showMessageDialog(this,"Update Successfully!");
         clear();
         tname.setText("");
         tphone.setText("");
         taddress.setText("");
         tallergies.setText("");
         con.close();
        }catch(Exception e){
        
        }
      }
    }//GEN-LAST:event_updatebuttonActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void txtSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchKeyReleased
        DefaultTableModel model = (DefaultTableModel)table1.getModel();
        TableRowSorter<DefaultTableModel> Model = new TableRowSorter<>(model);
        table1.setRowSorter(Model);
        Model.setRowFilter(RowFilter.regexFilter(txtSearch.getText()));
    }//GEN-LAST:event_txtSearchKeyReleased

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed

        DefaultTableModel model = (DefaultTableModel)table1.getModel();
        TableRowSorter<DefaultTableModel> Model = new TableRowSorter<>(model);
        table1.setRowSorter(Model);
        Model.setRowFilter(RowFilter.regexFilter(txtSearch.getText()));

    }//GEN-LAST:event_btnsearchActionPerformed

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSearchActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Patient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Patient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Patient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Patient.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Patient().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Clear;
    private javax.swing.JButton Delete;
    private javax.swing.JComboBox<String> Gender;
    private javax.swing.JButton btnsearch;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private java.awt.Label label1;
    private javax.swing.JLabel label4;
    private javax.swing.JLabel label5;
    private javax.swing.JButton save;
    private javax.swing.JTable table1;
    private javax.swing.JTextPane taddress;
    private javax.swing.JTextPane tallergies;
    private com.toedter.calendar.JDateChooser tdate;
    private javax.swing.JTextField tname;
    private javax.swing.JTextField tphone;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JButton updatebutton;
    // End of variables declaration//GEN-END:variables
}
